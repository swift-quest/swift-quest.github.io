/*:
今度は自分で書いてみましょう。

↓はヒーリングの魔法（まほう）で HP を 80 回復するプログラムです。 *[if 文（イフぶん）](glossary://if%20%E6%96%87)* を使って、現在（げんざい） HP が最大（さいだい） HP を超（こ）えてしまわないようにして下さい。

`x` には 1 から 153 までの何の値（あたい）が入っているかわかりません。現在 HP が最大 HP を超えた場合でも超えなかった場合でも正しく動作するようにして下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}
let x = 80
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let maxHp = 153
var hp = x

hp = hp + 80

print("HP \(hp)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nlet maxHp = 153\nvar hp = x\n\nhp = hp + 80\n\nif hp > maxHp {\n  hp = maxHp\n}\n\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 153\n")
//#-end-hidden-code