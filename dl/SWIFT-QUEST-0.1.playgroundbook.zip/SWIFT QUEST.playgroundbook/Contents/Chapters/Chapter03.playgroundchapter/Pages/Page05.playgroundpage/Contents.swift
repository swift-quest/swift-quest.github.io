/*:
*[if 文（イフぶん）](glossary://if%20%E6%96%87)* には色々な条件（じょうけん）を書くことができます。 `>` があるならもちろん `<` もあります。 `a < b` と書くと「 `a` が `b` より小さい」という条件を表します。

魔王（まおう）の HP が勇者（ゆうしゃ）の攻撃（こうげき）のダメージより小さかった場合、「まおうをやっつけた。」と表示（ひょうじ）する必要（ひつよう）があります。この条件は `hp2 < damage1` と表すことができます。

そのように↓のプログラムを変更（へんこう）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}
let x = 40
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let name1 = "ゆうしゃ"

let name2 = "まおう"
var hp2 = x

let damage1 = 52

print("\(name1)のこうげき。\(name2)に\(damage1)のダメージ。")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nlet name1 = \"ゆうしゃ\"\n\nlet name2 = \"まおう\"\nvar hp2 = x\n\nlet damage1 = 52\n\nprint(\"\\(name1)のこうげき。\\(name2)に\\(damage1)のダメージ。\")\n\nif hp2 < damage1 {\n  print(\"\\(name2)をやっつけた。\")\n}\n```", answerOutput: "ゆうしゃのこうげき。まおうに52のダメージ。\nまおうをやっつけた。\n")
//#-end-hidden-code