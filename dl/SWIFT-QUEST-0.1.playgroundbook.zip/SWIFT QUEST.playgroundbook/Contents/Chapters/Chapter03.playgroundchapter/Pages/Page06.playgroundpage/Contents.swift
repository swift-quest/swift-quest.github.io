/*:
実は、前のページのプログラムにはまちがいがあります。 `hp2 < damage1` という条件では、 `hp2` と `damage1` がぴったり同じだった場合、魔王（まおう）の HP は 0 になるのにやっつけたことになりません。

`hp2 < damage1` の条件に、 `hp2` と `damage1` が等しい場合も含（ふく）むには `<` の代わりに `<=` を使います。算数や数学で言う ≦ の意味になります。 `a <= b` は、「 `a` が `b` よりも小さい、または等しい」という条件になります。もちろん、 `<=` があるなら `>=` もあります。

↓のプログラムを変更（へんこう）して、魔王の HP がぴったり 52 のときでも正しく動作するようにして下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let name1 = "ゆうしゃ"

let name2 = "まおう"
var hp2 = 52

let damage1 = 52

print("\(name1)のこうげき。\(name2)に\(damage1)のダメージ。")

if hp2 < damage1 {
  print("\(name2)をやっつけた。")
}
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nlet name1 = \"ゆうしゃ\"\n\nlet name2 = \"まおう\"\nvar hp2 = 52\n\nlet damage1 = 52\n\nprint(\"\\(name1)のこうげき。\\(name2)に\\(damage1)のダメージ。\")\n\nif hp2 <= damage1 {\n  print(\"\\(name2)をやっつけた。\")\n}\n```", answerOutput: "ゆうしゃのこうげき。まおうに52のダメージ。\nまおうをやっつけた。\n")
//#-end-hidden-code