/*:
僧侶（そうりょ）が勇者（ゆうしゃ）にヒーリングの魔法（まほう）を使ったとき、勇者が死んでいたら「ゆうしゃにはきかなかった。」と表示（ひょうじ）しました。もし勇者が死んで **いなかったら** 「ゆうしゃのHPがかいふくした。」と表示する必要（ひつよう）があります。つまり、「もし〜なら」だけでなく「そうでなければ」も必要（ひつよう）ということです。

「そうでなければ」を書くには __*[else 節（エルスせつ, else clause ）](glossary://else%20%E7%AF%80)*__ を使います。↓のように書くと、 *[if 文（イフぶん）](glossary://if%20%E6%96%87)* の条件（じょうけん）が満（み）たされなかった場合に `else` の後の `{}` の中が実行されます。実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let name1 = "ゆうしゃ"
var hp1 = 20

let name3 = "そうりょ"

print("\(name3)はヒーリングのまほうをつかった。")

if hp1 == 0 {
  print("\(name1)にはきかなかった。")
} else {
  print("\(name1)のHPがかいふくした。")
}
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`hp1` は `20` なので `hp1 == 0` という条件（じょうけん）は満（み）たされません。そのため `else` の `{}` の中が実行され、「ゆうしゃのHPがかいふくした。」が実行されます。\n\n`var hp1 = 0` に変更（へんこう）すると、 `else` の `{}` の中は実行されずに「ゆうしゃにはきかなかった。」が表示（ひょうじ）されるので試（ため）してみて下さい。"), output: standardOutput.output, answer: "```swift\nlet name1 = \"ゆうしゃ\"\nvar hp1 = 20\n\nlet name3 = \"そうりょ\"\n\nprint(\"\\(name3)はヒーリングのまほうをつかった。\")\n\nif hp1 == 0 {\n  print(\"\\(name1)にはきかなかった。\")\n} else {\n  print(\"\\(name1)のHPがかいふくした。\")\n}\n```", answerOutput: "そうりょはヒーリングのまほうをつかった。\nゆうしゃのHPがかいふくした。\n")
//#-end-hidden-code