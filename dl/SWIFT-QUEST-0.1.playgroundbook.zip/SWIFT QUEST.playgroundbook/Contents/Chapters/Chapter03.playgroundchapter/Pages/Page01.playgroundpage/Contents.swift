/*:
最大（さいだい） HP 153 、現在（げんざい） HP 100 のときに、ヒーリングの魔法（まほう）で HP を 80 回復（かいふく）したとします。そのまま書けば↓のようになります。しかし、 HP は最大 HP を超（こ）えて回復してしまいます。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let maxHp = 153
var hp = 100

hp = hp + 80

print("HP \(hp)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "HP が 180 になってしまいました。最大（さいだい） HP は 153 なので、このままではいけません。\n\n次のページではこれを解決（かいけつ）する方法（ほうほう）を説明（せつめい）します。"), output: standardOutput.output, answer: "```swift\nlet maxHp = 153\nvar hp = 100\n\nhp = hp + 80\n\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 180\n")
//#-end-hidden-code