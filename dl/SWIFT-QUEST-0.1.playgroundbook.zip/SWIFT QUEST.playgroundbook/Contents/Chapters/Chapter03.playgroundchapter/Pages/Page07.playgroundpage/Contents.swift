/*:
`a == b` と書くと「 `a` と `b` が等しい」という意味になります。 `=` ではなく `==` なのは、 `=` は *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* を表すのに使われているからです。「等しくない」という条件（じょうけん）は `!=` で書けます（数学の ≠ ）。

ヒーリングの魔法（まほう）で仲間（なかま）の HP を回復（かいふく）しようとしたけど、その前に敵（てき）の攻撃（こうげき）で死んでしまうことがあります。ヒーリングでは仲間を生き返らせることはできないので、その場合は「◯◯にはきかなかった。」と表示（ひょうじ）しなければなりません。死んでいるという条件は「 HP が 0 と等しい」と言い換（か）えられます。

↓は僧侶（そうりょ）が勇者（ゆうしゃ）の HP を回復（かいふく）しようとするプログラムです。勇者が死んでいる場合には「ゆうしゃにはきかなかった。」と表示するようにを変更（へんこう）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}
let x = 0
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let name1 = "ゆうしゃ"
var hp1 = x

let name3 = "そうりょ"

print("\(name3)はヒーリングのまほうをつかった。")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nlet name1 = \"ゆうしゃ\"\nvar hp1 = x\n\nlet name3 = \"そうりょ\"\n\nprint(\"\\(name3)はヒーリングのまほうをつかった。\")\n\nif hp1 == 0 {\n  print(\"\\(name1)にはきかなかった。\")\n}\n```", answerOutput: "そうりょはヒーリングのまほうをつかった。\nゆうしゃにはきかなかった。\n")
//#-end-hidden-code