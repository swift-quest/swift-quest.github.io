/*:
*[if 文（イフぶん）](glossary://if%20%E6%96%87)* の条件（じょうけん）が満（み）たされなかった場合、本当に `{}` の中が実行されないか確認してみましょう。

↓は現在（げんざい） HP を 50 に変更（へんこう）したプログラムです。 HP が 80 回復しても 130 なので `hp > maxHp` は満（み）たされません。 `{}` の中が実行されないか確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let maxHp = 153
var hp = 50

hp = hp + 80

if hp > maxHp {
  hp = maxHp
}

print("HP \(hp)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "回復（かいふく）した後でも `hp` は `130` なので `hp > maxHp` という条件（じょうけん）は `130 > 153` で満（み）たされません。そのため *[if 文（イフぶん）](glossary://if%20%E6%96%87)* の `{}` の中の `hp = maxHp` は実行されず、 `HP 130` が表示（ひょうじ）されます。"), output: standardOutput.output, answer: "```swift\nlet maxHp = 153\nvar hp = 50\n\nhp = hp + 80\n\nif hp > maxHp {\n  hp = maxHp\n}\n\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 130\n")
//#-end-hidden-code