/*:
ヒーリングで HP を回復（かいふく）した結果（けっか）、もし `hp` が `maxHp` を超（こ）えてしまった場合には `hp` を `maxHp` と同じにしなければなりません。

「もし〜なら」を書くには __*[if 文（イフぶん, if statement ）](glossary://if%20%E6%96%87)*__ を使います。↓のように書くと、 `if` の後の条件 `hp > maxHp` が正しい場合にだけ `{}` の中が実行されます。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let maxHp = 153
var hp = 100

hp = hp + 80

if hp > maxHp {
  hp = maxHp
}

print("HP \(hp)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`hp = hp + 80` で `hp` が `180` になるので `hp > maxHp` という条件（じょうけん）は `180 > 153` で満（み）たされます。そのため *[if 文（イフぶん）](glossary://if%20%E6%96%87)* の `{}` の中が実行され、 `hp = maxHp` で `hp` が `153` になります。"), output: standardOutput.output, answer: "```swift\nlet maxHp = 153\nvar hp = 100\n\nhp = hp + 80\n\nif hp > maxHp {\n  hp = maxHp\n}\n\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 153\n")
//#-end-hidden-code