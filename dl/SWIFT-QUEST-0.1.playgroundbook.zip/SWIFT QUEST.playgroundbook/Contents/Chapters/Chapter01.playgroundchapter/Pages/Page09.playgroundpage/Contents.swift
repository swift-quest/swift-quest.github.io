/*:
もっと複雑（ふくざつ）な計算をすることもできます。

攻撃（こうげき）したときのダメージを、 攻撃力（こうげきりょく）から防御力（ぼうぎょりょく）をひき、それを 2 でわって計算することにしましょう。攻撃力が 36 、防御力が 22 だと、 36 - 22 = 14 、 14 ÷ 2 = 7 なので 7 のダメージを与（あた）えることになります。

この計算は `(36 - 22) / 2` と書くことができます。この `()` は算数の `()` と同じです。プログラムで書いた式は算数と同じで、たし算やひき算よりも先にかけ算やわり算が計算されます。そのため、 `36 - 22 / 2` と書いてしまうと、 22 / 2 = 11 が先に計算され、 36 - 11 = 25 のダメージとなってしまいます。

まずは、 `()` がないと本当に `22 / 2` が先に計算されて、結果（けっか）が 25 になってしまうか見てみましょう。↓のプログラムを実行して結果を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print(36 - 22 / 2)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "結果は `25` になりましたね。 `-` より `/` が先に計算されたのがわかると思います。"), output: standardOutput.output, answer: "```swift\nprint(36 - 22 / 2)\n```", answerOutput: "25\n")
//#-end-hidden-code