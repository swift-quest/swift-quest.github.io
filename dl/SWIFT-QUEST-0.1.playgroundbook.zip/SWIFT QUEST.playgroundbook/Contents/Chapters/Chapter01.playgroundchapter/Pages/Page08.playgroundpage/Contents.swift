/*:
次はわり算をやってみましょう。わり算も ÷ で書くことができません。代わりに `/` （スラッシュ）を使います。たとえば、 6 ÷ 2 を計算したいときには `6 / 2` と書きます。

防御力（ぼうぎょりょく）が 58 のとき、デプロテクションの魔法（まほう）を使って防御力を半分にしました。半分になった後の防御力を `/` を使って計算して表示（ひょうじ）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(58 / 2)\n```", answerOutput: "29\n")
//#-end-hidden-code