/*:
もう少し RPG っぽい表示（ひょうじ）をしてみましょう。

`print` を複数（ふくすう）回使えば複数行に分けてを表示（ひょうじ）することができます。 1 行には一つの命令（めいれい）しか実行できないので、 `print` も↓のように複数行に分けて書きます。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print("ゆうしゃ")
print("HP 153")
print("MP 25")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "RPG っぽい表示（ひょうじ）ができましたね！\n\n`print` 一つにつき 1 行が表示されているのがわかると思います。"), output: standardOutput.output, answer: "```swift\nprint(\"ゆうしゃ\")\nprint(\"HP 153\")\nprint(\"MP 25\")\n```", answerOutput: "ゆうしゃ\nHP 153\nMP 25\n")
//#-end-hidden-code