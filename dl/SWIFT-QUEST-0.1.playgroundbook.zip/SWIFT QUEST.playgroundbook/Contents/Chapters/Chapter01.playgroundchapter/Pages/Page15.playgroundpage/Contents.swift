/*:
`153 - 5` という式の計算結果（けっか）が埋（う）めこまれた *[文字列（もじれつ）](glossary://%E6%96%87%E5%AD%97%E5%88%97)* を作るには、 __*[文字列補間（もじれつほかん, String interpolation ）](glossary://%E6%96%87%E5%AD%97%E5%88%97%E8%A3%9C%E9%96%93)*__ を使います。↓のように `"` でかこまれた中に `\()` と書くと、その `()` の中の式が計算され、その結果が *[文字列](glossary://%E6%96%87%E5%AD%97%E5%88%97)* に埋めこまれます。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print("HP \(153 - 5)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "今度は `153 - 5` を計算した結果（けっか）が埋（う）めこまれて、 `HP 148` と表示されましたね。このように *[文字列補間（もじれつほかん）](glossary://%E6%96%87%E5%AD%97%E5%88%97%E8%A3%9C%E9%96%93)* を使えば式が埋（う）めこまれた *[文字列（もじれつ）](glossary://%E6%96%87%E5%AD%97%E5%88%97)* を作ることができます。\n\nなお、 `\\` はバックスラッシュという記号です。 `/` （スラッシュ）とは別（べつ）の記号なので注意して下さい。"), output: standardOutput.output, answer: "```swift\nprint(\"HP \\(153 - 5)\")\n```", answerOutput: "HP 148\n")
//#-end-hidden-code