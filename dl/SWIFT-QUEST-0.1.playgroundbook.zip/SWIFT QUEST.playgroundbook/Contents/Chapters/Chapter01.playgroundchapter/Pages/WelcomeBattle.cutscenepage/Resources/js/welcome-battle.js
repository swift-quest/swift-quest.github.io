let texts = [
"ようこそ！ <ruby>SWIFT<rt>スウィフト</rt></ruby> <ruby>QUEST<rt>クエスト</rt></ruby> の世界へ。",
"<ruby>SWIFT<rt>スウィフト</rt></ruby> <ruby>QUEST<rt>クエスト</rt></ruby> は、 <ruby>RPG<rt>アールピージー</rt></ruby> を <strong>作りながら</strong> 楽しくプログラミングを身につけるための <ruby>Playground<rt>プレイグラウンド</rt></ruby> <ruby>Book<rt>ブック</rt></ruby> です。<ruby>対象<rt>たいしょう</rt></ruby>は小学生（高学年）から大人までです。",
"RPG といえば<ruby>勇者<rt>ゆうしゃ</rt></ruby>と<ruby>魔王<rt>まおう</rt></ruby>です。どんなゲームを作るのか、まずは<ruby>勇者<rt>ゆうしゃ</rt></ruby>になって<ruby>魔王<rt>まおう</rt></ruby>と<ruby>戦<rt>たた</rt></ruby>ってみて下さい。"
];
let next = "battle.html";