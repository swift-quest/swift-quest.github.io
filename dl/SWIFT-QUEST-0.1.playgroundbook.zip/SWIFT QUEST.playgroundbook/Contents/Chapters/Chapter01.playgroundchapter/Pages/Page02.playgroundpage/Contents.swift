/*:
今度は自分で書いてみましょう。 `print(153)` と書いて実行して下さい。

プログラムを書くにはキーボードが必要（ひつよう）です。キーボードを出すには「ここをタップしてプログラムを書いてください」の部分をタップしたあとで、右下の「^」ボタンをおしてください。

「▶ Run My Code」ボタンを押したときに英語（えいご）のエラーメッセージが出たら、プログラムが何かおかしくて実行できないということです。たとえば、 `print(153` のように最後（さいご）の `)` を忘れるとエラーになり●が表示されます。その場合は、おかしな行の左がわにオレンジの●が表示されるので、プログラムをなおして下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(153)\n```", answerOutput: "153\n")
//#-end-hidden-code