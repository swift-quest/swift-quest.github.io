/*:
同じように攻撃（こうげき）のダメージを計算してみましょう。

攻撃力（こうげきりょく）が 162 、防御力（ぼうぎょりょく）が 58 のときのダメージを `(攻撃力 - 防御力) / 2` で計算して、結果（けっか）を表示（ひょうじ）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint((162 - 58) / 2)\n```", answerOutput: "52\n")
//#-end-hidden-code