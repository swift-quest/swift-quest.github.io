/*:
数字ばかり表示（ひょうじ）していてもおもしろくありません。ステータスっぽく、 `HP 153` と表示してみましょう。

しかし、 `print(HP 153)` と書いて実行してもエラーになってしまいます。 `print` の `()` の中に数字や式は書けましたが、 HP のような文字は書けません。↓のように `"` で文字をかこむことで、 `"` にかこまれた部分をそのまま表示することができます。

プログラムを実行して `HP 153` と表示されることを確認して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print("HP 153")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "ちゃんと `HP 153` と表示されましたね。 `\"` でかこめば `print` で文字も表示できることがわかったと思います。\n\nなお、 `\"` は英語（えいご）で使われる、ダブルクォーテーションという記号です。日本語でいう「」と同じような意味を持ちます。"), output: standardOutput.output, answer: "```swift\nprint(\"HP 153\")\n```", answerOutput: "HP 153\n")
//#-end-hidden-code