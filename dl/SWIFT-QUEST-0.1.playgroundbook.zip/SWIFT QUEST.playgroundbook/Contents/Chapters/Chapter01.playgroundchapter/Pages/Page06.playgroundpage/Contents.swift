/*:
前のページでは `-` を使ってひき算をしました。今度はたし算をやってみましょう。算数と同じように `+` を使えばたし算ができます。

HP が 42 のとき、ヒーリングの魔法（まほう）を使って HP を 80 回復（かいふく）しました。回復した後の HP を `+` で計算して表示（ひょうじ）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(42 + 80)\n```", answerOutput: "122\n")
//#-end-hidden-code