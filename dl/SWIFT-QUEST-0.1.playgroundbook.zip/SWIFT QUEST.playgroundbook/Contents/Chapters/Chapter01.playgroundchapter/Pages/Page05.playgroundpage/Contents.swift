/*:
今度はまた自分で書いてみましょう。 HP が 342 のときに 156 のダメージを受けたときの HP を表示して下さい。自分で計算するのではなく、 `-` を使ってコンピューターに計算させましょう。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。人間だと少し大変（たいへん）な 3 ケタのひき算も、コンピューターなら一瞬（いっしゅん）で計算できます。"), output: standardOutput.output, answer: "```swift\nprint(342 - 156)\n```", answerOutput: "186\n")
//#-end-hidden-code