/*:
`print` の `()` の中を変（か）えれば表示される数も変わります。

HP が 153 のとき、敵（てき）の攻撃（こうげき）で 5 のダメージを受けると、 HP は 148 になります。 `print` を使って 148 を表示してみて下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(148)\n```", answerOutput: "148\n")
//#-end-hidden-code