/*:
前に `print(153 - 5)` でダメージを受けた後の HP を表示しました。やはりダメージの計算はコンピューターにしてもらいところです。 `153 - 5` をコンピューターに計算させながら、 `148` ではなく `HP 148` と表示（ひょうじ）するにはどうすればいいでしょうか。

`"` の中はそのまま表示されてしまうので↓のように書くと `HP 153 - 5` と表示されてしまいます。実行して確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print("HP 153 - 5")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`153 - 5` の部分は計算されずにそのまま表示（ひょうじ）されてしまいました。これでは困（こま）るので、次のページでは式の計算結果（けっか）が埋（う）めこまれた *[文字列（もじれつ）](glossary://%E6%96%87%E5%AD%97%E5%88%97)* を作る方法（ほうほう）を説明（せつめい）します。"), output: standardOutput.output, answer: "```swift\nprint(\"HP 153 - 5\")\n```", answerOutput: "HP 153 - 5\n")
//#-end-hidden-code