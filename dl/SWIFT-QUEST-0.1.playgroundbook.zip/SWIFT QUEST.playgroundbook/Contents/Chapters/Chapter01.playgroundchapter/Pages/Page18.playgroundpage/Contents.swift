/*:
今度は自分で複数（ふくすう）行の表示（ひょうじ）をやってみましょう。

次のように表示してください。

`まほうつかい`\
`HP 77`\
`MP 58`
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(\"まほうつかい\")\nprint(\"HP 77\")\nprint(\"MP 58\")\n```", answerOutput: "まほうつかい\nHP 77\nMP 58\n")
//#-end-hidden-code