/*:
今度はかけ算をやってみましょう。かけ算は算数とちがって × で書くことができません。代わりに `*` （アスタリスク）を使います。たとえば、 2 × 3 を計算したいときには `2 * 3` と書きます。

攻撃力（こうげきりょく）が 162 のとき、ストライキングの魔法（まほう）を使って攻撃力を 2 倍にしました。 2 倍になった後の攻撃力を `*` を使って計算して表示（ひょうじ）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(162 * 2)\n```", answerOutput: "324\n")
//#-end-hidden-code