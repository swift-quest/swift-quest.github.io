/*:
今度は `()` をつけてみましょう。

`36 - 22` に `()` をつけると `(36 - 22) / 2` になります。これを `print` の `()` の中に入れると↓のようになります。今度は `36 - 22` が先に計算されて、結果（けっか）が `7` になることを確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print((36 - 22) / 2)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "今度は計算結果（けっか）が `7` になりました。 `()` をつけたらちゃんと `()` の中が先に計算されましたね。"), output: standardOutput.output, answer: "```swift\nprint((36 - 22) / 2)\n```", answerOutput: "7\n")
//#-end-hidden-code