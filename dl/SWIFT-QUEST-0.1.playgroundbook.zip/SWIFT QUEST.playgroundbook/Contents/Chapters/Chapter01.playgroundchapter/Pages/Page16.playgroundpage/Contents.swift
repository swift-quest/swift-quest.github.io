/*:
今度は自分で *[文字列補間（もじれつほかん）](glossary://%E6%96%87%E5%AD%97%E5%88%97%E8%A3%9C%E9%96%93)* を使ってみましょう。

MP 25 のときにヒーリングの魔法（まほう）を使って MP を 5 消費（しょうひ）しました。ヒーリング使用後の MP を表示（ひょうじ）しましょう。 `25 - 5` という計算式を　`\()` を使って埋（う）めこんで、 `MP 20` と表示して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(\"MP \\(25 - 5)\")\n```", answerOutput: "MP 20\n")
//#-end-hidden-code