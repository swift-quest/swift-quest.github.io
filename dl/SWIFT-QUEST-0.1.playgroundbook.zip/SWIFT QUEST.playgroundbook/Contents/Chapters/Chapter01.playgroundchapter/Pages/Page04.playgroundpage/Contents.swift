/*:
前のページでは、 153 - 5 = 148 を自分で計算し、 `print(148)` と書きました。しかし、せっかくコンピューターを使っているのだから、計算はコンピューターにやってもらいたいところです。 RPG をプレイしていても、ダメージを受けたときに自分で HP を計算したりしませんよね。

実は、 `print` の `()` の中には、↓のように数字だけじゃなくて計算式を書くこともできます。実行してみて下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print(153 - 5)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`153 - 5` と表示（ひょうじ）されるのではなく、計算結果（けっか）の `148` が表示されましたね。 `print` の `()` の中に計算式を書いたら計算結果を表示してくれます。"), output: standardOutput.output, answer: "```swift\nprint(153 - 5)\n```", answerOutput: "148\n")
//#-end-hidden-code