import PlaygroundSupport

PlaygroundPage.current.liveView = StandardOutputViewController.create()