/*:
どんなにゲームでも、画面に表示（ひょうじ）できければはじまりません。はじめに、画面に文字を表示する方法（ほうほう）を学びましょう。

今、 HP が 153 とします。画面に 153 と表示するには `print(153)` と書いて実行します。 `print` （プリント）は `()` の中を表示する命令（めいれい）です。

「▶ Run My Code」ボタンをおしてプログラムを実行してみてください。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print(153)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "画面のオレンジ色の部分に `153` と表示（ひょうじ）されましたね。 `print` は `()` の中の数字を画面に表示します。今は `()` の中が `153` だったので画面に `153` と表示されたわけです。"), output: standardOutput.output, answer: "```swift\nprint(153)\n```", answerOutput: "153\n")
//#-end-hidden-code