/*:
同じように HP を表示（ひょうじ）してみましょう。 HP 153 から 5 のダメージを受けて HP が 148 になりました。このときの HP を `HP 148` のように表示して下さい。前のページでやったように、 `"` でかこめば、数字や式だけでなく文字も `print` で表示できます。

この `""` でかこまれた部分を、文字が列のように並（なら）んでいるので __*[文字列（もじれつ, Character string ）](glossary://%E6%96%87%E5%AD%97%E5%88%97)*__ と言います。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nprint(\"HP 148\")\n```", answerOutput: "HP 148\n")
//#-end-hidden-code