/*:
`153 - 5 - 10 - 7` のように式が長くなるのを防（ふせ）ぐには、計算の結果（けっか）をどこかにとっておいて、後で使える必要があります。

__*[変数（へんすう, Variable ）](glossary://%E5%A4%89%E6%95%B0)*__ を使えばそれできます。たとえば、↓のようにすれば *[変数](glossary://%E5%A4%89%E6%95%B0)* `hp` に `153 - 5` の計算結果をとっておいて、後からそれを使うことができます。↓を実行してみて下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
var hp = 153 - 5
print(hp)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`148` と表示されましたね。これは、 `153 - 5` の計算結果（けっか）である `148` が *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` に入れられて、それを `print` で表示したからです。 `print(hp)` のように、 `print` の `()` の中に *[変数](glossary://%E5%A4%89%E6%95%B0)* を書けば、変数に入れられた値（あたい）を表示することができます。\n\n`var` は新しい *[変数](glossary://%E5%A4%89%E6%95%B0)* を作るときに必要（ひつよう）なキーワードです。 `print(hp)` のように *[変数](glossary://%E5%A4%89%E6%95%B0)* を使うときには必要ありません。\n\n*[変数](glossary://%E5%A4%89%E6%95%B0)* の名前は小文字（こもじ）でつけるのが一般的（いっぱんてき）です。 `HP` ではなく小文字の `hp` としたのはそのためです。"), output: standardOutput.output, answer: "```swift\nvar hp = 153 - 5\nprint(hp)\n```", answerOutput: "148\n")
//#-end-hidden-code