/*:
最大（さいだい） MP 、現在（げんざい） MP ともに 25 だとします。ヒーリングの魔法（まほう）を使って MP を 5 消費（しょうひ）したとき、ヒーリングを使う前と使った後の MP を次のように表示（ひょうじ）して下さい。

`MP 25`\
`MP 20`

ただし、最大 MP を `maxMp` 、現在 MP を `mp` で表し、必要（ひつよう）に応（おう）じて *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* と *[定数（ていすう）](glossary://%E5%AE%9A%E6%95%B0)* を使い分けて下さい。また、ヒーリングを使った後の `mp` はプログラムで計算して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nlet maxMp = 25\nvar mp = maxMp\n\nprint(\"MP \\(mp)\")\nmp = mp - 5\nprint(\"MP \\(mp)\")\n```", answerOutput: "MP 25\nMP 20\n")
//#-end-hidden-code