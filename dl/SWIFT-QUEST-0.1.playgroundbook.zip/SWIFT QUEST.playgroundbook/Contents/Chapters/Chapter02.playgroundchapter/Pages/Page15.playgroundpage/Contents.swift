/*:
`var` の代わりに `let` と書くこともできます。 `let` の場合、後から *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* して値（あたい）を変更（へんこう）することができなくなります。`let` で作られた場合は *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* とは呼（よ）ばず、 __*[定数（ていすう, Constant ）](glossary://%E5%AE%9A%E6%95%B0)*__ と言います。

たとえば、↓では最大（さいだい） HP を表す *[定数](glossary://%E5%AE%9A%E6%95%B0)* `maxHp` を作っています。戦闘（せんとう）中は最大 HP が変（か）わることはないので、まちがえて変更（へんこう）してしまわないように *[定数](glossary://%E5%AE%9A%E6%95%B0)* にします。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let maxHp = 153
print(maxHp)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`var` と同じように `let` でも動作することが確認（かくにん）できましたね。\n\n`maxHp` のように、値（あたい）を後から変更（へんこう）することがない場合には、まちがって変更（へんこう）してしまわないように *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* ではなく *[定数（ていすう）](glossary://%E5%AE%9A%E6%95%B0)* を使います。まずは `let` を考えて、それではダメな場合だけ `var` を使うようにしましょう。"), output: standardOutput.output, answer: "```swift\nlet maxHp = 153\nprint(maxHp)\n```", answerOutput: "153\n")
//#-end-hidden-code