/*:
今度は自分で書いてみましょう。

`var` を使って *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` を作り、 `153 - 5` の計算結果（けっか）を入れて下さい。また、 `print(hp)` で計算結果を表示（ひょうじ）してみましょう。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nvar hp = 153 - 5\nprint(hp)\n```", answerOutput: "148\n")
//#-end-hidden-code