/*:
↓のようにすれば、 `148` を自分で計算する必要はありません。必要（ひつよう）な計算はすべてコンピューターがやってくれます。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print("HP \(153)")
print("HP \(153 - 5)")
print("HP \(153 - 5 - 10)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正しく表示（ひょうじ）できました。しかし、この方法（ほうほう）ではダメージを受ける度（たび）にどんどん式が長くなってしまいます。次に 7 のダメージを受けたら `153 - 5 - 10 - 7` です。キリがありません。"), output: standardOutput.output, answer: "```swift\nprint(\"HP \\(153)\")\nprint(\"HP \\(153 - 5)\")\nprint(\"HP \\(153 - 5 - 10)\")\n```", answerOutput: "HP 153\nHP 148\nHP 138\n")
//#-end-hidden-code