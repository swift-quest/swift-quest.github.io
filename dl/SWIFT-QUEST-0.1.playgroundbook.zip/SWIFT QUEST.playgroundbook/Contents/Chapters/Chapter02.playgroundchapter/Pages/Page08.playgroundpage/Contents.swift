/*:
`hp = 148` の `148` は計算式で書きたいところです。前の前のページで、 `hp - 5` で `148` を計算しました。これを組み合わせれば↓のように書けます。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
var hp = 153
print(hp)
hp = hp - 5
print(hp)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "2 回目の `print` で、ちゃんと `148` と表示（ひょうじ）されました。 `hp = hp - 5` が実行されて、 `hp - 5` の結果（けっか）である `148` が新しい `hp` の値（あたい）として *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* されたからです。\n\n`hp = hp - 5` という式は、 `=` の左側（ひだりがわ）と右側（みぎがわ）が等しくないので、算数や数学ではまちがった式です。しかし、 Swift や他の多くのプログラミング言語（げんご）では、 `=` は右側（みぎがわ）の値を左側（ひだりがわ）の *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* に *[代入](glossary://%E4%BB%A3%E5%85%A5)* するという意味になります。"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(hp)\nhp = hp - 5\nprint(hp)\n```", answerOutput: "153\n148\n")
//#-end-hidden-code