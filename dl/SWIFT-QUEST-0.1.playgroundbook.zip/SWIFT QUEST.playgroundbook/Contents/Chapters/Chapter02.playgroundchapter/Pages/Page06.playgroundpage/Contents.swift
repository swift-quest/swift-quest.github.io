/*:
*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* は `print` で表示（ひょうじ）するだけでなく、計算式の中で使うこともできます。↓では、変数 `hp` に `153` を入れた後で、計算式の中で `hp` を使っています。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
var hp = 153
print(hp)
print(hp - 5)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` には `153` が入っているので、 `print(hp)` では `153` が表示（ひょうじ）されます。また、 `hp - 5` は `153 - 5` の意味になるので、 `print(hp - 5)` では `148` が表示されます。\n\nこのように、 *[変数](glossary://%E5%A4%89%E6%95%B0)* を計算式の中で使うことができます。"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(hp)\nprint(hp - 5)\n```", answerOutput: "153\n148\n")
//#-end-hidden-code