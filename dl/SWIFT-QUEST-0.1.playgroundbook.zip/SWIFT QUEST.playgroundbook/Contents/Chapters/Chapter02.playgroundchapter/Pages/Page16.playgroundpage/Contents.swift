/*:
↓は、 HP 153 のときにダメージを受けて HP が 148 になるプログラムです。最大（さいだい） HP を *[定数（ていすう）](glossary://%E5%AE%9A%E6%95%B0)* `maxHp` で、現在（げんざい） HP を *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` で表しています。

しかし、ダメージを受けて HP をへらすときに、まちがえて `maxHp` に *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* してしまいました。 `maxHp` は *[定数](glossary://%E5%AE%9A%E6%95%B0)* なので後から値（あたい）を変更（へんこう）することはできません。エラーとなり `maxHp = 148` の行の左側（ひだりがわ）にオレンジの●が表示されます。

`maxHp` への *[代入](glossary://%E4%BB%A3%E5%85%A5)* ではなく `hp` への *[代入](glossary://%E4%BB%A3%E5%85%A5)* に変更して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let maxHp = 153
var hp = maxHp

maxHp = 148
print(hp)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "*[定数（ていすう）](glossary://%E5%AE%9A%E6%95%B0)* だと後から値（あたい）を変更（へんこう）できないことがわかりましたね。\n\n`var hp = maxHp` にも注目して下さい。現在（げんざい） HP を最大（さいだい） HP と同じにしたいだけなら `var hp = 153` と書くこともできます。しかし、 `let maxHp = 160` に修正（しゅうせい）された場合に `hp` も `var hp = 160` と修正しなければいけなくなります。一つの修正のために複数（ふくすう）箇所（かしょ）を修正しなくていい方がいいですよね。なので、 `var hp = maxHp` のように書くようにしましょう。"), output: standardOutput.output, answer: "```swift\nlet maxHp = 153\nvar hp = maxHp\n\nhp = 148\nprint(hp)\n```", answerOutput: "148\n")
//#-end-hidden-code