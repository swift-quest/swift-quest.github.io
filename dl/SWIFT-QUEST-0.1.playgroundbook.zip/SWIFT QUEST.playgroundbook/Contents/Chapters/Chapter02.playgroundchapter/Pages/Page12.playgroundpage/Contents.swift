/*:
前に次のようなプログラムを作りました。

`print("HP \(153)")`\
`print("HP \(153 - 5)")`\
`print("HP \(153 - 5 - 10)")`

HP の計算が `153 - 5 - 10` のように、ダメージを受ける度（たび）に長くなってしまい困（こま）りました。 *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* を使ってこれを解決（かいけつ）しましょう。

↓のようにすれば式が長くなることを防げます。実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
var hp = 153
print("HP \(hp)")
hp = hp - 5
print("HP \(hp)")
hp = hp - 10
print("HP \(hp)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "ちゃんと `HP 153`, `HP 148`, `HP 138` と表示されましたね。\n\n1. *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* を式の中で使う（ `hp - 5` など）\n2. *[変数](glossary://%E5%A4%89%E6%95%B0)* に *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* して値（あたい）を変更（へんこう）する（ `hp = ...` ）\n3. *[文字列補間（もじれつほかん）](glossary://%E6%96%87%E5%AD%97%E5%88%97%E8%A3%9C%E9%96%93)* で *[変数](glossary://%E5%A4%89%E6%95%B0)* を埋めこんで表示する（ `print(\"HP \\(hp)\")` ）\n\nこの組み合わせで目的（もくてき）を達成（たっせい）できました。\n\nこのように、プログラミングでは自分の持っている道具をどのように組み合わせて使うかが重要（じゅうよう）になります。"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(\"HP \\(hp)\")\nhp = hp - 5\nprint(\"HP \\(hp)\")\nhp = hp - 10\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 153\nHP 148\nHP 138\n")
//#-end-hidden-code