/*:
同じように、魔王（まおう）の攻撃（こうげき）を作って下さい。

前ページまでのプログラムの続（つづ）きを書いて下さい。ダメージは `(攻撃力 - 防御力) / 2` で計算して下さい。 `damage1` はすでに使われているので新しく `damage2` を作って、計算されたダメージをそこに *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* して下さい。また、攻撃の後には前ページと同じようにステータスを表示（ひょうじ）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}
let name1 = "ゆうしゃ"
var hp1 = 153
let attack1 = 162
let defense1 = 97

let name2 = "まおう"
var hp2 = 999
let attack2 = 185
let defense2 = 58

print(name1)
print("HP \(hp1)")
print()
print(name2)
print("HP \(hp2)")
print()

let damage1 = (attack1 - defense2) / 2

print("\(name1)のこうげき。\(name2)に\(damage1)のダメージ。")
print()

hp2 = hp2 - damage1

print(name1)
print("HP \(hp1)")
print()
print(name2)
print("HP \(hp2)")
print()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nlet damage2 = (attack2 - defense1) / 2\n\nprint(\"\\(name2)のこうげき。\\(name1)に\\(damage2)のダメージ。\")\nprint()\n\nhp1 = hp1 - damage2\n\nprint(name1)\nprint(\"HP \\(hp1)\")\nprint()\nprint(name2)\nprint(\"HP \\(hp2)\")\nprint()\n```", answerOutput: "ゆうしゃ\nHP 153\n\nまおう\nHP 999\n\nゆうしゃのこうげき。まおうに52のダメージ。\n\nゆうしゃ\nHP 153\n\nまおう\nHP 947\n\nまおうのこうげき。ゆうしゃに44のダメージ。\n\nゆうしゃ\nHP 109\n\nまおう\nHP 947\n\n")
//#-end-hidden-code