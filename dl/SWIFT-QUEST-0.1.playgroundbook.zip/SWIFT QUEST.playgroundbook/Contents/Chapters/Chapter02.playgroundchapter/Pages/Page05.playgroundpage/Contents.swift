/*:
*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* には計算結果（けっか）だけでなく、ただの値（あたい）も入れることができます。たとえば、↓のように書くと *[変数](glossary://%E5%A4%89%E6%95%B0)* `hp` に `153` を入れることができます。

実行して `153` が表示（ひょうじ）されることを確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
var hp = 153
print(hp)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "`153` と表示（ひょうじ）されましたね。 *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* には計算結果（けっか）だけでなくただの値（あたい）も入れられることがわかったと思います。"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(hp)\n```", answerOutput: "153\n")
//#-end-hidden-code