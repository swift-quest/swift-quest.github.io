let texts = [
"プログラミングをするには、プログラミング<ruby>言語<rt>げんご</rt></ruby>という言葉を使います。",
"人間の<ruby>言語<rt>げんご</rt></ruby>にも日本語や<ruby>英語<rt>えいご</rt></ruby>など色々あるように、プログラミング<ruby>言語<rt>げんご</rt></ruby>にもたくさんの<ruby>種類<rt>しゅるい</rt></ruby>があります。",
"<ruby>SWIFT<rt>スウィフト</rt></ruby> <ruby>QUEST<rt>クエスト</rt></ruby> では <ruby>Swift<rt>スウィフト</rt></ruby> というプログラミング<ruby>言語<rt>げんご</rt></ruby>を使います。これまでに書いたのもすべて <ruby>Swift<rt>スウィフト</rt></ruby> です。",
"どうして <ruby>SWIFT<rt>スウィフト</rt></ruby> <ruby>QUEST<rt>クエスト</rt></ruby> のために <ruby>Swift<rt>スウィフト</rt></ruby> を<ruby>選<rt>えら</rt></ruby>んだのでしょうか？",
"ぼくは、 <ruby>Swift<rt>スウィフト</rt></ruby> は今プログラミングをはじめる人にぴったりの<ruby>言語<rt>げんご</rt></ruby>だと考えています。",
"<ruby>Swift<rt>スウィフト</rt></ruby> は<ruby>初<rt>はじ</rt></ruby>めてプログラミングをする人にとってわかりやすいように作られています。その上、プロも使う<ruby>本格的<rt>ほんかくてき</rt></ruby>な<ruby>言語<rt>げんご</rt></ruby>です。",
"2014 年に生まれた新しい<ruby>言語<rt>げんご</rt></ruby>なので、プログラミングにおける<ruby>最新<rt>さいしん</rt></ruby>の考え方も学べます。",
"また、 <ruby>Swift<rt>スウィフト</rt></ruby> はこの数年で人気が一番<ruby>急上昇<rt>きゅうじょうしょう</rt></ruby>した<ruby>言語<rt>げんご</rt></ruby>です。",
"今は <ruby>iPhone<rt>アイフォーン</rt></ruby> や <ruby>iPad<rt>アイパッド</rt></ruby> のアプリを作るために使われることが多いですが、これからますます<ruby>幅広<rt>はばひろ</rt></ruby>い<ruby>目的<rt>もくてき</rt></ruby>で使われると考えられています。",
"<ruby>本格的<rt>ほんかくてき</rt></ruby>なのに<ruby>初<rt>はじ</rt></ruby>めてでもわかりやすく、<ruby>最新<rt>さいしん</rt></ruby>の考え方も学べる。アプリを作るなど<ruby>実際<rt>じっさい</rt></ruby>に役に立ち、これからますます人気が高まりそう。",
"これからプログラミングをはじめる人にぴったりの<ruby>言語<rt>げんご</rt></ruby>だと思いませんか？",
"小学生がプログラミングをするときには <ruby>Scratch<rt>スクラッチ</rt></ruby> という<ruby>言語<rt>げんご</rt></ruby>が人気です。もしかすると<ruby>友達<rt>ともだち</rt></ruby>がやっていたり、聞いたことがあるかもしれません。",
"<ruby>Scratch<rt>スクラッチ</rt></ruby> は子ども向けの絵本のように、目で見てわかりやすいように作られた<ruby>言語<rt>げんご</rt></ruby>です。",
"しかし、勉強のためにはいいのですが、 <ruby>Scratch<rt>スクラッチ</rt></ruby> で<ruby>実際<rt>じっさい</rt></ruby>に役に立つものを作ろうとするとむずしいことが多いです。",
"ぼくが小学生でプログラミングをはじめたころは、 <ruby>Scratch<rt>スクラッチ</rt></ruby> はまだありませんでした。絵本のような<ruby>言語<rt>げんご</rt></ruby>でなくても小学生が<ruby>理解<rt>りかい</rt></ruby>できることを、ぼくは知っています。",
"小学生のための <ruby>Scratch<rt>スクラッチ</rt></ruby> の<ruby>教材<rt>きょうざい</rt></ruby>はたくさんありますが、<ruby>本格的<rt>ほんかくてき</rt></ruby>な<ruby>言語<rt>げんご</rt></ruby>で楽しく学ぶ<ruby>方法<rt>ほうほう</rt></ruby>があってもいいんじゃないか。",
"そういう理由で <ruby>Swift<rt>スウィフト</rt></ruby> を<ruby>選<rt>えら</rt></ruby>びました。"
];
let next = "@next";