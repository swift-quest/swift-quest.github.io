/*:
今度は自分で書いてみましょう。

*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` 、 *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* 、 _文字列（もじれつほかん）_ を使って、次のように表示（ひょうじ）して下さい。

`HP 153`\
`HP 148`\
`HP 138`
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(\"HP \\(hp)\")\nhp = hp - 5\nprint(\"HP \\(hp)\")\nhp = hp - 10\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 153\nHP 148\nHP 138\n")
//#-end-hidden-code