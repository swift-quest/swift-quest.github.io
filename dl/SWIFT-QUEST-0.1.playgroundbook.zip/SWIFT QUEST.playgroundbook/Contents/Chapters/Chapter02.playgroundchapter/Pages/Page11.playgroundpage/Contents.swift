/*:
今度は自分で書いてみましょう。

*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` を作ってそこに `153` を *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* し、 *[文字列補間（もじれつほかん）](glossary://%E6%96%87%E5%AD%97%E5%88%97%E8%A3%9C%E9%96%93)* を使って `HP 153` と表示（ひょうじ）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(\"HP \\(hp)\")\n```", answerOutput: "HP 153\n")
//#-end-hidden-code