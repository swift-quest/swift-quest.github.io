/*:
今度は自分で書いてみましょう。

HP 153 のときに 5 のダメージを受けて HP が 148 になりました。ダメージを受ける前後の HP を表示（ひょうじ）して下さい。次のようにプログラムを作りましょう。

1. *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `hp` に `153` を *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)*
2. `hp` を表示
3. `hp - 5` を計算して、その結果（けっか）を `hp` に *[代入](glossary://%E4%BB%A3%E5%85%A5)*
4. `hp` を表示
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(hp)\nhp = hp - 5\nprint(hp)\n```", answerOutput: "153\n148\n")
//#-end-hidden-code