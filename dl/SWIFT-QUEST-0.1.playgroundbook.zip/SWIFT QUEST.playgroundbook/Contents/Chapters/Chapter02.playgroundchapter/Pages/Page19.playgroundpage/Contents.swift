/*:
次は勇者（ゆうしゃ）の攻撃（こうげき）を作ります。

ダメージは前にやったように `(攻撃力 - 防御力) / 2` で計算しましょう。計算されたダメージは、「まおうに◯◯のダメージ。」と表示（ひょうじ）する部分と、魔王（まおう）の HP をへらす部分で 2 回使います。同じ計算を 2 回するのはムダなので、計算結果（けっか）を一度 *[定数（ていすう）](glossary://%E5%AE%9A%E6%95%B0)* `damage1` に *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* します。

↓は前にページのプログラムの続（つづ）きです。実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}
let name1 = "ゆうしゃ"
var hp1 = 153
let attack1 = 162
let defense1 = 97

let name2 = "まおう"
var hp2 = 999
let attack2 = 185
let defense2 = 58

print(name1)
print("HP \(hp1)")
print()
print(name2)
print("HP \(hp2)")
print()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let damage1 = (attack1 - defense2) / 2

print("\(name1)のこうげき。\(name2)に\(damage1)のダメージ。")
print()

hp2 = hp2 - damage1

print(name1)
print("HP \(hp1)")
print()
print(name2)
print("HP \(hp2)")
print()
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "このプログラムは前のページで書いたプログラムの続きとして実行されます。最初（さいしょ）に勇者（ゆうしゃ）と魔王（まおう）のステータスが表示（ひょうじ）されるのは、前のページに書いたプログラムで `print` されているからです。\n\n`print(ゆうしゃのこうげき。まおうに\\(damage1)のダメージ。\")` ではなく、 `print(\"\\(name1)のこうげき。\\(name2)に\\(damage1)のダメージ。\")` となっていることに注目して下さい。 `name1` と `name2` を使っているので、たとえ名前が変わってもこの行を変更（へんこう）する必要（ひつよう）はありません。\n\ndamage （ダメージ）はダメージを英語（えいご）で書いたものです。"), output: standardOutput.output, answer: "```swift\nlet damage1 = (attack1 - defense2) / 2\n\nprint(\"\\(name1)のこうげき。\\(name2)に\\(damage1)のダメージ。\")\nprint()\n\nhp2 = hp2 - damage1\n\nprint(name1)\nprint(\"HP \\(hp1)\")\nprint()\nprint(name2)\nprint(\"HP \\(hp2)\")\nprint()\n```", answerOutput: "ゆうしゃ\nHP 153\n\nまおう\nHP 999\n\nゆうしゃのこうげき。まおうに52のダメージ。\n\nゆうしゃ\nHP 153\n\nまおう\nHP 947\n\n")
//#-end-hidden-code