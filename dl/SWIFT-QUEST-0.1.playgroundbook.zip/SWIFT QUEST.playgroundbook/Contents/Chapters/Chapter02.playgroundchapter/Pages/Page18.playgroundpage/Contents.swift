/*:
これまでに学んだことを使って、 1 ターン分の戦闘（せんとう）を作ってみましょう。

勇者（ゆうしゃ）と魔王（まおう）が戦（たたか）うものとします。まずは勇者と魔王の HP 、攻撃力（こうげきりょく）、防御力（ぼうぎょりょく）を作りましょう。今は、魔法（まほう）は使わずただ攻撃するだけにしたいので MP は作りません。

HP を `hp` 、攻撃力を `attack` （アタック）、防御力を `defense` （ディフェンス）で表します。また、勇者と魔王の名前を `name` （ネイム）で表します。今、勇者と魔王の二人がいるのでそれぞれ `hp1`, `hp2` のように、勇者には `1` を、魔王には `2` をつけます。

実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
let name1 = "ゆうしゃ"
var hp1 = 153
let attack1 = 162
let defense1 = 97

let name2 = "まおう"
var hp2 = 999
let attack2 = 185
let defense2 = 58

print(name1)
print("HP \(hp1)")
print()
print(name2)
print("HP \(hp2)")
print()
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "勇者（ゆうしゃ）と魔王（まおう）のステータスが表示（ひょうじ）されました。これまで *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* や *[定数（ていすう）](glossary://%E5%AE%9A%E6%95%B0)* には数しか *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* してきませんでしたが、 `name1` や `name2` のように *[文字列（もじれつ）](glossary://%E6%96%87%E5%AD%97%E5%88%97)* を *[代入](glossary://%E4%BB%A3%E5%85%A5)* することもできます。\n\n変更（へんこう）する必要（ひつよう）のある `hp1` と `hp2` だけ が *[変数](glossary://%E5%A4%89%E6%95%B0)* で、他は *[定数](glossary://%E5%AE%9A%E6%95%B0)* なことに注意して下さい。\n\n`print()` は何も表示せず改行（かいぎょう）（次の行に進むこと）だけします。"), output: standardOutput.output, answer: "```swift\nlet name1 = \"ゆうしゃ\"\nvar hp1 = 153\nlet attack1 = 162\nlet defense1 = 97\n\nlet name2 = \"まおう\"\nvar hp2 = 999\nlet attack2 = 185\nlet defense2 = 58\n\nprint(name1)\nprint(\"HP \\(hp1)\")\nprint()\nprint(name2)\nprint(\"HP \\(hp2)\")\nprint()\n```", answerOutput: "ゆうしゃ\nHP 153\n\nまおう\nHP 999\n\n")
//#-end-hidden-code