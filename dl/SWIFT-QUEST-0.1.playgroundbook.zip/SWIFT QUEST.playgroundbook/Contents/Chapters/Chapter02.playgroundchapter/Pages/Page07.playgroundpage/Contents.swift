/*:
*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* の値（あたい）は変更（へんこう）することもできます。 *[変数](glossary://%E5%A4%89%E6%95%B0)* の値を変更するには、 `=` を使ってもう一度値を入れなおします。 `=` で *[変数](glossary://%E5%A4%89%E6%95%B0)* に値を入れることを __*[代入（だいにゅう, Assignment ）](glossary://%E4%BB%A3%E5%85%A5)*__ と言います。

↓は HP 153 のときにダメージを受けて 148 にへったことを表しています。実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
var hp = 153
print(hp)
hp = 148
print(hp)
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "最初（さいしょ）の `print(hp)` では `153` と表示（ひょうじ）されましたが、 2 回目の `print(hp)` では `148` と表示されました。 `hp` に `148` を *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* して `hp` の値（あたい）を変更（へんこう）したからです。\n\n`var hp = 153` では `var` が必要（ひつよう）だったのに、 `hp = 148` では `var` が要（い）らないことに注意して下さい。 `var` は新しい *[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* を作るときにだけ必要です。 `hp = 148` のときには、すでに *[変数](glossary://%E5%A4%89%E6%95%B0)* `hp` が作られているので `var` は必要ありません。"), output: standardOutput.output, answer: "```swift\nvar hp = 153\nprint(hp)\nhp = 148\nprint(hp)\n```", answerOutput: "153\n148\n")
//#-end-hidden-code