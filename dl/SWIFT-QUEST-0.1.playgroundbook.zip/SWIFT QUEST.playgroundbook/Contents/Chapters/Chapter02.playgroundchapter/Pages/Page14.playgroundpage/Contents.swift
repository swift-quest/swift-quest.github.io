/*:
今度は MP を表示（ひょうじ）してみましょう。

MP が 25 のとき、ヒーリングの魔法（まほう）を使って MP を 5 消費（しょうひ）、その後サンダーボルトの魔法を使って MP を 8 消費（しょうひ）しました。

*[変数（へんすう）](glossary://%E5%A4%89%E6%95%B0)* `mp` 、 *[代入（だいにゅう）](glossary://%E4%BB%A3%E5%85%A5)* 、 _文字列（もじれつほかん）_ を使って、次のように表示（ひょうじ）して下さい。

`MP 25`\
`MP 20`\
`MP 12`
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code  ここをタップしてプログラムを書いてください

//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正解（せいかい）です。おめでとうございます！"), output: standardOutput.output, answer: "```swift\nvar mp = 25\nprint(\"MP \\(mp)\")\nmp = mp - 5\nprint(\"MP \\(mp)\")\nmp = mp - 8\nprint(\"MP \\(mp)\")\n```", answerOutput: "MP 25\nMP 20\nMP 12\n")
//#-end-hidden-code