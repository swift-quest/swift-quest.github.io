/*:
HP 153 で 5 のダメージを受けたら HP は 148 になります。さらに 10 にダメージを受けたら HP は 138 になります。これをプログラムで計算して

`HP 153`\
`HP 148`\
`HP 138`

と表示（ひょうじ）するにはどうすれば良いでしょうか。

たとえば、↓のように書けます。実行して結果（けっか）を確認（かくにん）して下さい。
*/
//#-hidden-code
var standardOutput = StandardOutput()
standardOutput.start()
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    standardOutput.print(items, separator: separator, terminator: terminator)
}

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-editable-code 
print("HP \(153)")
print("HP \(153 - 5)")
print("HP \(148 - 10)")
//#-end-editable-code
//#-hidden-code

checkAnswer(checker: SimpleAnswerChecker(passMessage: "正しく表示（ひょうじ）できました。しかし、これでは自分で `148` を計算しなければなりません。せっかく `print(\"HP \\(153 - 5)\")` でコンピューターに `148` を計算させているのに、 `print(\"HP \\(148 - 10)\")` と書くために自分で `148` を書かなければならないのはイマイチです。"), output: standardOutput.output, answer: "```swift\nprint(\"HP \\(153)\")\nprint(\"HP \\(153 - 5)\")\nprint(\"HP \\(148 - 10)\")\n```", answerOutput: "HP 153\nHP 148\nHP 138\n")
//#-end-hidden-code