import UIKit
import PlaygroundSupport

public class StandardOutputViewController: UIViewController {
    fileprivate var textView: UITextView!

    public override func loadView() {
        let frame = UIScreen.main.bounds
        textView = UITextView(frame: frame)
        textView.isEditable = false
        textView.textColor = UIColor.white
        textView.font = UIFont(name: "Courier", size: 32)!
        textView.textContainerInset = UIEdgeInsetsMake(80.0, 20.0, 0.0, 20.0)
        textView.backgroundColor = UIColor(red: 0.996, green: 0.294, blue: 0.149, alpha: 1.0)
        view = textView
    }

    public class func create() -> StandardOutputViewController {
        return StandardOutputViewController(nibName: nil, bundle: Bundle.main)
    }

    public func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
        textView.text = textView.text + items.map { "\($0)" }.joined(separator: separator) + terminator
    }
}

extension StandardOutputViewController: PlaygroundLiveViewMessageHandler {
    public enum Action: String {
        case print = "print"
        case clear = "clear"
    }

    public func receive(_ data: PlaygroundValue) {
        guard case let .dictionary(actionNameToValue) = data else { return }

        for (actionName, value) in actionNameToValue {
            guard let action = Action(rawValue: actionName) else { continue }
            switch action {
            case .print:
                guard case let .string(message) = value else { fatalError("\(value)") }
                print(message, terminator: "")
            case .clear:
                textView.text = ""
            }
        }
    }
}

public func send(action: StandardOutputViewController.Action, value: PlaygroundValue) {
    let page = PlaygroundPage.current
    if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
        proxy.send(.dictionary([action.rawValue: value]))
    }
}