import PlaygroundSupport

public func checkAnswer(checker: AnswerChecker, output: String, answer: String, answerOutput: String) {
    PlaygroundPage.current.assessmentStatus = checker.checkAnswer(output: output, answer: answer, answerOutput: answerOutput)
}

public protocol AnswerChecker {
    func checkAnswer(output: String, answer: String, answerOutput: String) -> PlaygroundPage.AssessmentStatus
}

public struct SimpleAnswerChecker: AnswerChecker {
    let passMessage: String

    public init(passMessage: String) {
        self.passMessage = passMessage
    }

    public func checkAnswer(output: String, answer: String, answerOutput: String) -> PlaygroundPage.AssessmentStatus {
        if output == answerOutput {
            return .pass(message: passMessage + "\n\n[次のページに進む](@next)")
        } else {
            return .fail(hints: [], solution: answer)
        }
    }
}