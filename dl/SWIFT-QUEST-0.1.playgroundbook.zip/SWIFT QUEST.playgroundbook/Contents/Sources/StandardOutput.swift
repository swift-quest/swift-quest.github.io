import PlaygroundSupport

public struct StandardOutput {
    public private(set) var output: String
    
    public init() {
        output = ""
    }
    
    public mutating func start() {
        clear()
    }
    
    public mutating func clear() {
        output = ""
        send(action: .clear, value: .string(""))
    }
    
    public mutating func print(_ items: [Any], separator: String = " ", terminator: String = "\n") {
        let message = items.map { "\($0)" }.joined(separator: separator) + terminator
        output += message
        send(action: .print, value: .string(message))
    }
}
